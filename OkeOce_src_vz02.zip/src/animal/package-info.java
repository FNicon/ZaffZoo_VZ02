/**
 * 
 */
/**
 * @author Fathur
 *
 */
package animal;